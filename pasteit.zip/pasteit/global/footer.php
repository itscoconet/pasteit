<footer class="footer">
      	<div class="container">
        	<p class="text-muted">PasteIT was developed by <a href="" target="_blank">CVBE</a>, using PHP, MySQL and BootStrap 3.3</p>
      	</div>
    </footer>	


     <!-- Prism Syntax Highlighter -->
  	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.0/prism.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.0/themes/prism.min.css">
	<script src="js/prism-components.js"></script>
	<script src="js/prism-utopia.js"></script>
	<script src="js/prism-library-components.js"></script>