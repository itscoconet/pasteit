<?php 
require('global/connect.php');
require('functions.php');
raw();
?>